// This script controls the mechanics behind a "top trumps"-style game.
// Developed by the data journalism team of the Hessischer Rundfunk in 2018

/*  Copyright (C) 2018  Till Hafermann, Miguel Pascual Sanina, hr-Datenteam

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

// CUSTOMIZATION: To build your own game, change the text to display

// dropdown for choosing a card
var chooseCardMsg = "(Wähle eine Karte)";
// error message if no card is chosen
var noCardSelectionMsG = "Keine Karte gewählt";
// error message if wrong number of categories is chosen
var noCategorySelectionMsG = "Select exactly five categories";
var turnWonMsg = "Gewonnen!"; // turn won
var turnLostMsg = "Verloren"; // turn lost
var turnDrawMsg = "Unentschieden"; // turn results in draw
var gameWonMsg = "Spiel gewonnen: "; // game won
var gameLostMsg = "Spiel verloren: "; // game lost
var gameDrawMsg = "Unentschieden: "; // game results in draw
// text to display in infoline while player choses category
var turnWaitMsg = "Chose categories";
// text to display in infoline when game is over
var gameOverMsg = "Spiel aus";
// text to display in infoline when summary is shown
var gameWaitMsg = "Ein neues Spiel?";


// Game is configured for seven rounds and five categories per card.
// Change this here. Progress bar percentage should be 100/number of Rounds.

var numberOfRounds = 9;
var numberOfCategories = 7;
var progressBarPercentage = "width: 11.11%"; //100 div number of rounds
var currentRound = 1;


// CUSTOMIZATION: Enter your data for the cards here
// Example data for countries of the EU taken from various Wikipedia pages (Oct. 22, 2018)

// Data header: Names of the categories, first one = title of the card
var data_header = ["Modell", "Hubraum", "Leistung", "Drehmoment", "Gewicht", "Tankinhalt", "Top-Speed", "Preis"];

// Category names for summary
var summary_header = ["", "Hubraum", "Leistung", "Drehmoment", "Gewicht", "Tankinhalt", "Top-Speed", "Preis"];

// Units if necessary, first entry always empty
var data_suffix = ["", " ccm", " PS", " Nm", " kg", " l", " km/h", " EUR"];

// Specify which number wins: larger or smaller, first entry always empty
var data_comparison = ["", "larger", "larger", "larger", "smaller", "larger", "larger", "larger"];

// One array per card, structure: Title first, then category values

//Yamaha
//var YamahaYZFR1 = ["Yamaha YZF-R1", 998, 200, 112.4, 200, 17, 300, 18995]; nicht neu
var YamahaTenere = ["Yamaha Ténéré 700", 689, 74, 68, 180, 16, 180, 8000];//kein endgültiger Preis, VMAX geschätzt
var YamahaYZFR3 = ["Yamaha YZF-R3", 321, 42, 29.6, 169, 14, 170, 5895];

//Triump
var TriumpScrambler1200XE = ["Triump Scrambler 1200 XE", 1200, 90, 110, 207, 16, 190, 14550];
var TriumpScrambler1200XC = ["Triump Scrambler 1200 XC", 1200, 90, 110, 205, 16, 190, 13550];
var TriumpStreetTwin = ["Triump Street Twin", 900, 65, 80, 198, 12, 180, 9300];
var TriumpStreetScrambler900 = ["Triump Street Scrambler 900", 900, 65, 80, 203, 12, 180, 10900];
var TriumpSpeedTrippleRS = ["Triump Speed Tripple RS", 1050, 150, 117, 192, 15.5, 250, 16150];
var TriumpSpeedTrippleS = ["Triump Speed Tripple S", 1050, 150, 117, 192, 15.5, 250, 13850];
var TriumpStreetCup = ["Triump Street Cup", 900, 55, 80, 200, 12, 180, 10500];

//Royal Enfield
var RoyalEnfieldInterceptor = ["Royal Enfield Interceptor", 648, 47, 52, 202, 13.7, 150, 6400]
var RoyalEnfieldContinentalGT = ["Royal Enfield Continental GT", 648, 47, 52, 198, 12.5, 150, 6400]

//Suzuki
var SuzukiGSXS1000 = ["Suzuki GSX-S 1000", 999, 150, 108, 215, 12, 240, 13000];//kein endgültiger Preis, VMAX geschätzt
var SuzukiSV650X = ["Suzuki SV 650 X", 645, 76, 64, 198, 14.5, 200, 6800];

//KTM
var KTM690SMCR = ["KTM 690 SMC R", 690, 75, 73.5, 147, 13.5, 180, 10799];
var KTM1290SUPERDUKEGT = ["KTM 1290 SUPER DUKE GT", 1301, 175, 141, 205, 23, 270, 18999];//Preis?
var KTM790AdventureR = ["KTM 790 Adventure R", 799, 95, 88, 189, 20, 210, 13399];
var KTM790Adventure = ["KTM 790 Adventure", 799, 95, 88, 189, 20, 210, 12399];

//MV Augusta
var MVAugustaBrutale800RRLH44 = ["MV Augusta Brutale 800 RR LH44", 798, 140, 87, 172, 16.5, 244, 24144];

//Moto Morini
var MotoMoriniCorsaro1200ZT = ["Moto Morini Corsaro 1200 ZT", 1187, 139, 125, 191, 16, 250, 15990];
//Moto Morini Milano
//Moto Morini Scrambler


//Moto Guzzi
var MotoGuzziV9BobberSport = ["Moto Guzzi V9 Bobber Sport", 853, 55, 65, 195, 15, 170, 11550];//nur Sport Version neu
var MotoGuzziAudaceCarbon = ["Moto Guzzi Audace Carbon", 1380, 96, 121, 314, 20.5, 195, 18850];
var MotoGuzziV85TT = ["Moto Guzzi V85 TT", 853, 80, 80, 229, 21, 180, 13000]; //kein endgültiger Preis
//Harley-Davidson
var HarleyDavidsonLiveWire = ["Harley-Davidson LiveWire", 0, 74, 70, 210, 0, 170, 28000]; //kein endgültiger Preis
var HarleyDavidsonIron1200 = ["Harley-Davidson Iron 1200", 1203, 67, 96, 256, 12.5, 180, 10995];
var HarleyDavidsonFXDR114 = ["Harley-Davidson FXDR 114", 1868, 91, 160, 303, 18.5, 190, 24595];
var HarleyDavidsonFortyEightSpecial = ["Harley-Davidson Forty-Eight Special", 1202, 67, 96, 256, 7.9, 180, 12195];

//Honda
//var HondaVFR800F = ["Honda VFR 800 F", 782, 106, 75, 246, 20.8, 240, 12655];
//var HondaCBR1000RR = ["Honda CBR 1000 RR", 1000, 192, 116, 195, 16, 22655];
var HondaCB500X = ["Honda CB 500 X", 471, 48, 43, 197, 17.1, 170, 6390];
var HondaCB500F = ["Honda CB 500 F", 471, 48, 43, 189, 17.1, 170, 6290];
var HondaGL1800 = ["Honda GL 1800", 1833, 126, 170, 405, 21.1, 180, 25595];
var HondaCBR500R = ["Honda CBR 500 R", 471, 48, 43, 192, 17.1, 175, 7090];
var HondaCBR650R = ["Honda CBR 650 R", 649, 95, 64, 207, 15.4, 200, 9000];
var HondaCB650R = ["Honda CB 650 R", 649, 95, 64, 202, 15.4, 200, 8000];

//Husquarna
//var Husquarna701Supermoto = ["Husquarna 701 Supermoto", 692, 74, 71, 145, 13, 180, 9995]; nicht neu
var HusquarnaSvartpilen701 = ["Husquarna Svartpilen 701", 692, 75, 72, 170, 12, 190, 10195];
var HusquarnaSvartpilen401 = ["Husquarna Svartpilen 401", 692, 44, 37, 160, 9.5, 156, 6295];
//var HusquarnaFS450 = ["Husquarna FS 450", 449, 63, 0, 112, 7, 130, 10850]; //keine Straßenzulassung

//Kawasaki

var KawasakiZ400 = ["Kawasaki Z400", 399, 45, 38, 168, 14, 170, 5895];
var KawasakiZX6R = ["Kawasaki ZX-6R", 636, 130, 70.8, 196, 17, 260, 12245];
var KawasakiVersys1000SE = ["Kawasaki Versys 1000 SE", 1043, 120, 102, 257, 21, 230, 16745];
var KawasakiW800Cafe = ["Kawasaki W 800 Cafe", 773, 48, 60, 216, 14, 170, 10945]; //Daten unvollständig
var KawasakiW800Street = ["Kawasaki W 800 Street", 773, 48, 60, 216, 14, 170, 10145]; //Daten unvollständig

//var KawasakiZX10RR = ["Kawasaki ZX-10RR", 998, 204, 115.7, 206, 17, 26395]; 
//var KawasakiH2 = ["Kawasaki H2", 998, 231, 141.7, 238, 17, 29900]; 
//var KawasakiZX10RKRT = ["Kawasaki ZX-10R KRT", 998, 200, 113.5, 203, 17, 18095];
//var KawasakiH2SXSE = ["Kawasaki H2 SX SE+", 998, 200, 137.3, 262, 19, 25595];
//var KawasakiZ1000SX = ["Kawasaki Z1000 SX", 1043, 142, 111, 235, 19, 13345];
//var KawasakiVersys650 = ["Kawasaki Versys 650", 649, 69, 64, 217, 21, 8495];

//Indian
var IndianFTR1200 = ["Indian FTR 1200", 1203, 120, 115, 225, 13, 220, 14690];
var IndianChieftain = ["Indian Chieftain", 1811, 110, 151, 361, 20.8, 180, 28390];
//Ducati
var DucatiPanigale1299RFE = ["Ducati Panigale 1299 R Final Edition", 1285, 209, 142, 190, 17, 300, 39900];
var DucatiPanigale959 = ["Ducati Panigale 959", 955, 150, 102, 207, 17, 270, 16790];
var DucatiPanigaleV4R = ["Ducati Panigale V4 R", 998, 221, 112, 193, 16, 300, 39900];
var DucatiDiavel1260S = ["Ducati Diavel 1260 S", 1262, 159, 129, 244, 17, 260, 19990];
var DucatiHypermotard950 = ["Ducati Hypermotard 950", 937, 114, 96, 200, 14.5, 220, 12490];
var DucatiHypermotard950SP = ["Ducati Hypermotard 950 SP", 937, 114, 96, 200, 14.5, 220, 16390];
var DucatiHypermotard950SP = ["Ducati Hypermotard 950 SP", 937, 114, 96, 200, 14.5, 220, 16390];
//var DucatiMultistrada1260Enduro = ["Ducati Multistrada 1260 Enduro", 1262, 158, 129.5, 230, 20, 250, 20500];
//var DucatiMultistrada950S  = ["Ducati Multistrada 950 S", 937, 113, 96, 225, 20, 210, 0];

//BMW
var BMWF850GSAdventure = ["BMW F 850 GS Adventure", 853, 95, 92, 244, 23, 200, 12950]; 
var BMWR1250GS = ["BMW R 1250 GS", 1254, 136, 143, 268, 20, 220, 16150]; 
var BMWR1250GSAdventure = ["BMW R 1250 GS Adventure", 1254, 136, 143, 268, 30, 220, 17700]; 
var BMWS1000RR = ["BMW S 1000 RR", 999, 207, 113, 197, 16.5, 300, 18750]; 
var BMWR1250GS = ["BMW R 1250 GS", 1254, 136, 143, 249, 20, 220, 16150]; 
var BMWR1250RT = ["BMW R 1250 RT", 1254, 136, 143, 279, 25, 230, 18000]; 
var BMWR1250RS = ["BMW R 1250 RS", 1254, 136, 143, 243, 18, 230, 14400]; 
var BMWR1250R = ["BMW R 1250 R", 1254, 136, 143, 239, 18, 230, 13750]; 


//Benelli
var BenelliLeoncino500Trail = ["Benelli Leoncino 500 Trail", 499, 47, 45, 207, 13.5, 150, 6170]; 
var BenelliTRK502X = ["Benelli TRK 502 X", 499, 48, 45, 210, 20, 145, 6170]; 

//Aprilia
//var ApriliaDorsoduro900 = ["Aprilia Dorsoduro 900", 896, 95, 90, 218, 11.5, 200, 9990];
//var ApriliaRSV4 = ["Aprilia RSV4", 999, 201, 115, 204, 18, 300, 18890];
var ApriliaTuonoV41100Factory = ["Aprilia Tuono V4 1100 Factory", 1077, 175, 121, 209, 18.5, 270, 16999];
//"", "Hubraum", "Leistung", "Drehmoment", "Gewicht", "Tankinhalt", "Spitze", "Preis"
//"", " ccm", " PS", " Nm", " kg", " l", " km/h",  EUR"];

// group cards in one array
var allCards = [
        //ApriliaRSV4, ApriliaDorsoduro900, 
        ApriliaTuonoV41100Factory,

        BenelliLeoncino500Trail, BenelliTRK502X,

        BMWF850GSAdventure, BMWR1250GS, BMWR1250GSAdventure, BMWS1000RR, BMWR1250RT, BMWR1250RS, BMWR1250R,

        DucatiPanigaleV4R, DucatiDiavel1260S, DucatiHypermotard950, DucatiHypermotard950SP, DucatiPanigale1299RFE, 
        DucatiPanigale959, //DucatiMultistrada950, DucatiMultistrada1260Enduro,

				KTM690SMCR, KTM1290SUPERDUKEGT, KTM790AdventureR, KTM790Adventure,

        HondaCB500X, HondaCB500F, HondaCBR500R, HondaCBR650R, HondaGL1800, HondaCB650R,
        //HondaVFR800F, HondaCBR1000RR,

        HusquarnaSvartpilen701, HusquarnaSvartpilen401, 

        IndianFTR1200, IndianChieftain,

        KawasakiZ400, KawasakiZX6R, KawasakiVersys1000SE, KawasakiW800Cafe, KawasakiW800Street, //KawasakiH2, KawasakiZX10RR, KawasakiZX10RKRT, KawasakiH2SXSE, KawasakiZ1000SX, KawasakiVersys650,  

        HarleyDavidsonLiveWire, HarleyDavidsonIron1200, HarleyDavidsonFXDR114, 
        HarleyDavidsonFortyEightSpecial,

        MotoGuzziAudaceCarbon, MotoGuzziV9BobberSport, MotoGuzziV85TT,

        MVAugustaBrutale800RRLH44,

        MotoMoriniCorsaro1200ZT,

        RoyalEnfieldInterceptor, RoyalEnfieldContinentalGT,

        SuzukiGSXS1000, SuzukiSV650X,

        TriumpScrambler1200XE, TriumpScrambler1200XC, TriumpStreetTwin, TriumpStreetScrambler900,
        TriumpSpeedTrippleRS, TriumpSpeedTrippleS, TriumpStreetCup,

        //YamahaYZFR1, 
        YamahaTenere, YamahaYZFR3
        ];

// list of cards in case player wants to choose a specific card to play with
// list of arrays with variable name and titel of card
var cardsList = [
  
  //Aprilia
  //["ApriliaRSV4", "Aprilia RSV4"], 
  //["ApriliaDorsoduro900", "Aprilia Dorsoduro 900"], 
  //["ApriliaRSV4", "Aprilia RSV4"],
  ["ApriliaTuonoV41100Factory", "Aprilia Tuono V4 1100 Factory"], 

  //Benelli
  ["BenelliLeoncino500Trail", "Benelli Leoncino 500 Trail"],
  ["BenelliTRK502X", "Benelli TRK 502 X"],
 
  //Augusta

  //BMW  
  ["BMWF850GSAdventure", "BMW F 850 GS Adventure"], 
  ["BMWR1250GS", "BMW R 1250 GS"], 
  ["BMWR1250GSAdventure", "BMW R 1250 GS Adventure"], 
  ["BMWS1000RR", "BMW S 1000 RR"], 
  ["BMWR1250RT", "BMW R 1250 RT"],
  ["BMWR1250RS", "BMW R 1250 RS"],  
  ["BMWR1250R", "BMW R 1250 R"], 
  
  //Brixton Glanville / Saxby 250

  //Ducati
	["DucatiPanigaleV4R", "Ducati Panigale V4 R"], 
  ["DucatiDiavel1260S", "Ducati Diavel 1260 S"],
  ["DucatiHypermotard950", "Ducati Hypermotard 950"],	
  ["DucatiHypermotard950SP", "Ducati Hypermotard 950 SP"], 
  ["DucatiPanigale1299RFE", "Ducati Panigale 1299 R Final Edition"],
  ["DucatiPanigale959", "Ducati Panigale 959"],
  ["DucatiMultistrada1260Enduro", "Ducati Multistrada 1260 Enduro"],
  ["DucatiMultistrada950", "Ducati Multistrada 950"],


  ["HondaCB500X", "Honda CB 500 X"],
  ["HondaCB500F", "Honda CB 500 F"],
  ["HondaCBR500R", "Honda CBR 500 R"], 
  ["HondaCBR650R", "Honda CBR 650 R"], 
  ["HondaCB650R", "Honda CB 650 R"],
  ["HondaGL1800", "Honda GL 1800"],
  //["HondaCBR1000RR", "Honda CBR 1000 RR"], nicht neu
  //["HondaVFR800F", "Honda VFR 800 F"], 
  //Honda CBF 450 L ??
    
  //["Husquarna701Supermoto", "Husquarna 701 Supermoto"], 
  //Husquarna Svartpilen 701
  ["HusquarnaSvartpilen701", "Husquarna Svartpilen 701"],
  ["HusquarnaSvartpilen401", "Husquarna Svartpilen 401"],

  ["HarleyDavidsonLiveWire", "Harley-Davidson LiveWire"],
  ["HarleyDavidsonIron1200", "Harley-Davidson Iron 1200"], 
  ["HarleyDavidsonFXDR114", "Harley-Davidson FXDR 114"],
  ["HarleyDavidsonFortyEightSpecial", "Harley-Davidson Forty-Eight Special"],

  ["IndianFTR1200", "Indian FTR 1200"],
  ["IndianChieftain", "Indian Chieftain"],

  ["KawasakiVersys1000SE", "Kawasaki Versys 1000 SE"],
  ["KawasakiZ400", "Kawasaki Z400"],
  ["KawasakiZX6R", "Kawasaki ZX-6R"],
  ["KawasakiW800Cafe", "Kawasaki W 800 Cafe"],
  ["KawasakiW800Street", "Kawasaki W 800 Street"],
  //["KawasakiZX10RR", "Kawasaki ZX-10RR"],
  //["KawasakiH2", "Kawasaki H2"],
  //["KawasakiZX10RKRT", "Kawasaki ZX-10R KRT"],
  //["KawasakiH2SXSE", "Kawasaki H2 SX SE+"],
  //["KawasakiZ1000SX", "Kawasaki Z1000 SX"],
  //["KawasakiVersys650", "Kawasaki Versys 650"], 

  //weiter Modelle als neu gekennzeichnet


  ["KTM690SMCR", "KTM 690 SMC R"], 
  ["KTM1290SUPERDUKEGT", "KTM 1290 SUPER DUKE GT"],
  ["KTM790AdventureR", "KTM 790 Adventure R"],
  ["KTM790Adventure", "KTM 790 Adventure"],
 
  //KTM 790 Enduro
  //KTM 690 Enduro

  ["MotoGuzziAudaceCarbon", "Moto Guzzi Audace Carbon"], 
  ["MotoGuzziV9BobberSport", "Moto Guzzi V9 Bobber Sport"], 
  ["MotoGuzziV85TT", "Moto Guzzi V85 TT"], 

  ["MVAugustaBrutale800RRLH44", "MV Augusta Brutale 800 RR LH44"], 

  ["MotoMoriniCorsaro1200ZT", "Moto Morini Corsaro 1200 ZT"], 
  
  //Royal Enfield 
  ["RoyalEnfieldInterceptor", "Royal Enfield Interceptor"],
  ["RoyalEnfieldContinentalGT", "Royal Enfield Continental GT"],
  
  //Suzuki
  ["SuzukiGSXS1000", "Suzuki GSX-S 1000"],
  ["SuzukiSV650X", "Suzuki SV 650 X"],

  //Triump  
  ["TriumpScrambler1200XE", "Triump Scrambler 1200 XE"], 
  ["TriumpScrambler1200XC", "Triump Scrambler 1200 XC"],
  ["TriumpStreetTwin", "Triump Street Twin"],
  ["TriumpStreetScrambler900", "Triump Street Scrambler 900"], 
  ["TriumpSpeedTrippleRS", "Triump Speed Tripple RS"],
  ["TriumpSpeedTrippleS", "Triump Speed Tripple S"],
  ["TriumpStreetCup", "Triump Street Cup"],

  //Yamaha
  //["YamahaYZFR1", "Yamaha YZF-R1"] //nicht neu
  ["YamahaTenere", "Yamaha Ténéré 700"],
  ["YamahaYZFR3", "Yamaha YZF-R3"],

  ];


// Inititate buttons and information displays
var startGameButton;
var startTurnButton;
var newGameButton;
var showSummaryButton;
var waitingButton;
var infoLine;
var summaryList;
var gameProgressBar;
var computerCardDiv;


// set width of hud and button container on small devices
var viewportWidth = $(window).width();

if (viewportWidth <= 576) {
  $("#hudcontent").css( "maxWidth", viewportWidth );
  $("#buttons").css( "maxWidth", viewportWidth );
  $("#infocontent").css( "maxWidth", viewportWidth );
}

// initiate variables for later use
var gameMode;
var chosenCard;
var chosenCategories;
var playerCards;
var computerCards;
var playerPoints;
var computerPoints;
var playerCount;
var computerCount;
var currentPlayerCard;
var currentComputerCard;
var stateOfGame;

// format numbers for display,
// decimal divider is ".", thousands separator is ","
function formatNumbers(num){
  return (
    num
      .toString()
      .replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1,")
	  // for German locale use lines below
      // .replace(".",",")
      // .replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1.")
    );
}

// function to randomly shuffle arrays
function shuffleCards() {
  //Shuffles an array
  var currentIndex = allCards.length;
  var temporaryValue;
  var randomIndex;

  // While there remain elements to shuffle...
  while (0 !== currentIndex) {

    // Pick a remaining element...
    randomIndex = Math.floor(Math.random() * currentIndex);
    currentIndex -= 1;

    // And swap it with the current element.
    temporaryValue = allCards[currentIndex];
    allCards[currentIndex] = allCards[randomIndex];
    allCards[randomIndex] = temporaryValue;
  }

}


//Set button-states
//1=game mode selection
//2=category selection
//3=start game
//4=start next turn
//5=turn in progress
//6=last turn finished
//7=showing summary

function updateButtons(state) {
  stateOfGame = state;
  switch(state) {
    case 1:
      // Show only game mode selectors
      document.getElementById("hud").style.display = "none";
      document.getElementById("hud2").style.display = "none";
      document.getElementById("getMode").style.display = "flex";
      document.getElementById("getCategories").style.display = "none";
      document.getElementById("summary").style.display = "none";
      document.getElementById("cards").style.display = "none";
      document.getElementById("buttons").style.display = "none";
      newGameButton.style.display = "none";
      // Reset summary
      while (summaryList.hasChildNodes()) {
        summaryList.removeChild(summaryList.lastChild);
      }

      getMode();
      break;
    case 2:
      // Show only category selectors
      document.getElementById("hud").style.display = "none";
      document.getElementById("hud2").style.display = "none";
      document.getElementById("getMode").style.display = "none";
      document.getElementById("getCategories").style.display = "flex";
      document.getElementById("summary").style.display = "none";
      document.getElementById("cards").style.display = "none";
      document.getElementById("buttons").style.display = "none";
      getCategories();
      break;
    case 3:
      // Disable all buttons, show "waiting"-button, hide summary, show carddeck
      document.getElementById("hud").style.display = "block";
//      document.getElementById("hud2").style.display = "flex";
      document.getElementById("getMode").style.display = "none";
      document.getElementById("getCategories").style.display = "none";
      document.getElementById("summary").style.display = "none";
      document.getElementById("cards").style.display = "block";
      document.getElementById("buttons").style.display = "flex";
      startGameButton.style.display = "none";
      startTurnButton.style.display = "none";
      newGameButton.style.display = "none";
      waitingButton.style.display = "inline";
      showSummaryButton.style.display = "none";
      infoLine.innerHTML = "";
      break;
    case 4:
      // Display button to start next turn
      // Modification to auto turn after 3 sec
      setTimeout(initTurn, 3000); //modified
      startGameButton.style.display = "none";
      startTurnButton.style.display = "none"; //modified: inline
      newGameButton.style.display = "none";
      waitingButton.style.display = "none";
      showSummaryButton.style.display = "none";
      break;
    case 5:
      // Disable all buttons, show "waiting"-button, reset infoline
      startGameButton.style.display = "none";
      startTurnButton.style.display = "none";
      newGameButton.style.display = "none";
      waitingButton.style.display = "inline";
      showSummaryButton.style.display = "none";
      infoLine.classList.remove("text-success");
      infoLine.classList.remove("text-danger");
      infoLine.classList.remove("text-warning");
      infoLine.classList.add("text-light");
      infoLine.innerHTML = "<h4 class='mb-1'>Runde " + currentRound + " von " +
                           numberOfRounds + "</h4>";
      break;
    case 6:
      // Show button to display summary after last turn
      startGameButton.style.display = "none";
      startTurnButton.style.display = "none";
      newGameButton.style.display = "none";
      waitingButton.style.display = "none";
      // Modification to auto summary after 3 sec
      showSummaryButton.style.display = "none"; //inline
      setTimeout(initSummary, 3000); //modified
      break;
    case 7:
      // Show summary, hide cards, show "new game"-button
      startGameButton.style.display = "none";
      startTurnButton.style.display = "none";
      newGameButton.style.display = "none"; //inline
      waitingButton.style.display = "none";
      showSummaryButton.style.display = "none";
      infoLine.style.display = "none";
      document.getElementById("summary").style.display = "block";
      document.getElementById("cards").style.display = "none";
      document.getElementById("hud2").style.display = "none";
      setTimeout(initNewGame, 6000); //modified
      break;
  }
}

function getMode() {
  // function to let user select a game mode:
  // either classic with a random card in each round
  // or play with one card throughout the entire game

  var cardsListDropdown = document.getElementById("chosenCardSelect");
  var noCardSelectionDiv = document.getElementById("noCardSelection");
  noCardSelectionDiv.innerHTML = "";

  // Reset list of cards to choose from first
  while (cardsListDropdown.hasChildNodes()) {
    cardsListDropdown.removeChild(cardsListDropdown.lastChild);
  }

  // Build list of all cards to choose from
  var chooseCardMsgElement = document.createElement("option");
  chooseCardMsgElement.value = "noSelection";
  var chooseCardMsgContent = document.createTextNode(chooseCardMsg);
  chooseCardMsgElement.appendChild(chooseCardMsgContent);
  cardsListDropdown.appendChild(chooseCardMsgElement);

  var newCardInList;
  var newCardInListContent;

  for (i = 0; i < cardsList.length; i+=1) {
    newCardInList = document.createElement("option");
    newCardInList.value = cardsList[i][0];
    newCardInListContent = document.createTextNode(cardsList[i][1]);
    newCardInList.appendChild(newCardInListContent);
    cardsListDropdown.appendChild(newCardInList);
  }


  // build random list of categories - delete this section if
  // getCategories() will be used
  // to use fixed order of categories: comment lines 399 to 419

  chosenCategories = [];
  for (i = 1; i < data_header.length; i+=1) {
    chosenCategories.push(i);
  }

  //var currentCatIndex = chosenCategories.length;
  //var temporaryCatValue;
  //var randomCatIndex;

  // While there remain elements to shuffle...
  //while (0 !== currentCatIndex) {

    // Pick a remaining element...
    //randomCatIndex = Math.floor(Math.random() * currentCatIndex);
    //currentCatIndex -= 1;

    // And swap it with the current element.
    //temporaryCatValue = chosenCategories[currentCatIndex];
    //chosenCategories[currentCatIndex] = chosenCategories[randomCatIndex];
    //chosenCategories[randomCatIndex] = temporaryCatValue;
  //}

  // Use number (specified before) of categories of shuffled list
  //chosenCategories = chosenCategories.slice(0, numberOfCategories);



  // Let player choose game mode
  $(document).on("click", "#randomCards", function() {
    gameMode = "random";
    initGame();
  });

  $(document).on("click", "#chosenCardButton", function() {
    gameMode = "fixedCard";
    chosenCard = $("#chosenCardSelect :selected").val();

    if (chosenCard == "noSelection") {
      noCardSelectionDiv.innerHTML = noCardSelectionMsG;
    } else {
      initGame();
    }

  });

}

function getCategories() {
  // function to let user select, which categories to play with:
  // either with five random categories
  // or with five fixed categories

  var categoriesList = document.getElementById("chosenCategoriesList");
  var noCategorySelectionDiv = document.getElementById("noCategorySelection");
  noCategorySelectionDiv.innerHTML = "";

  // Reset checkboxes for categories
  while (categoriesList.hasChildNodes()) {
    categoriesList.removeChild(categoriesList.lastChild);
  }

  // Build checkboxes with categories
  var newCategoryCheckbox;
  var newCategoryInput;
  var newCategoryLabel;
  var newCategoryLabelContent;

  for (i = 1; i < data_header.length; i+=1) {
    newCategoryCheckbox = document.createElement("div");
    newCategoryCheckbox.classList.add("custom-control", "custom-checkbox",
                                      "custom-control-inline");

    newCategoryInput = document.createElement("input");
    newCategoryInput.id = i;
    newCategoryInput.classList.add("custom-control-input");
    newCategoryInput.type = "checkbox";

    newCategoryLabel = document.createElement("label");
    newCategoryLabel.classList.add("custom-control-label");
    newCategoryLabel.setAttribute("for", i);
    newCategoryLabelContent = document.createTextNode(data_header[i]);
    newCategoryLabel.appendChild(newCategoryLabelContent);

    newCategoryCheckbox.appendChild(newCategoryInput);
    newCategoryCheckbox.appendChild(newCategoryLabel);

    categoriesList.appendChild(newCategoryCheckbox);
  }

  // Let player choose categories

  // If player chooses random categories, create random array of five numbers
  $(document).on("click", "#randomCategories", function() {
    chosenCategories = [];
    for (i = 1; i < data_header.length; i+=1) {
      chosenCategories.push(i);
    }

    var currentCatIndex = chosenCategories.length;
    var temporaryCatValue;
    var randomCatIndex;

    // While there remain elements to shuffle...
    while (0 !== currentCatIndex) {

      // Pick a remaining element...
      randomCatIndex = Math.floor(Math.random() * currentCatIndex);
      currentCatIndex -= 1;

      // And swap it with the current element.
      temporaryCatValue = chosenCategories[currentCatIndex];
      chosenCategories[currentCatIndex] = chosenCategories[randomCatIndex];
      chosenCategories[randomCatIndex] = temporaryCatValue;
    }

    // Use first five categories of shuffled list
    chosenCategories = chosenCategories.slice(0, numberOfCategories);

    initGame();

  });

  // if player chooses own categories, store in array
  $(document).on("click", "#chosenCategoriesButton", function() {
    chosenCategories = [];
    for (i = 1; i < data_header.length; i+=1) {
      currentCatID = "#" + i;
      if ($(currentCatID).is(":checked"))
        chosenCategories.push(i);
    }

    if (chosenCategories.length != numberOfCategories) {
      noCategorySelectionDiv.innerHTML = noCategorySelectionMsG;
    } else {
      initGame();
    }
  });

}

function buildDecks() {
  // Assign cards to player and computer according to game mode selection

  if (gameMode == "random") {
    // Deal 7 random cards each
    playerCards = allCards.slice(0, numberOfRounds);
    computerCards = allCards.slice(numberOfRounds, 18); //Achtung! Anzahl der Runden beachten! 
  } else {
    // assign the chosen card to player seven times
    playerCards = [];
    for (i = 0; i < numberOfRounds; i+=1) {
      playerCards.push(eval(chosenCard));
    }
    // remove chosen player card from cards, assign computer random cards
    chosenCardIndex = allCards.indexOf(eval(chosenCard));
    allCards.splice(chosenCardIndex, 1);
    computerCards = allCards.slice(0, numberOfRounds);
  }

}

function updateScore() {
  // function to display the current score
  playerCount = document.getElementById("player_count");
  computerCount = document.getElementById("computer_count");
  playerCount.innerHTML = playerPoints;
  computerCount.innerHTML = computerPoints;
}

function buildComputerCard() {
  // function to display the current card of the computer
  computerCardDiv.classList.toggle("flip");

  var computerCardBack = document.getElementById("computerCardBack");
  computerCardBack.style.height = $(playercard).height() + "px";

  var computercardBackHeader=document.getElementById("computercardBackHeader");
  computercardBackHeader.innerHTML =  currentComputerCard[0];


  setTimeout(function(){
    //wait with card content so as not to display it before card is flipped back

    // Change heading of computer card
    var computercardHeader = document.getElementById("computercard_header");
    computercardHeader.innerHTML = "<h3 class='m-3 card-title text-white'>" +
                                   currentComputerCard[0] + "</h3>";
    computercardHeader.style.height = "200px";
		computercardHeader.style.borderTopLeftRadius = "inherit";
		computercardHeader.style.borderTopRightRadius = "inherit";
		computercardHeader.style.textShadow = "0px 0px 4px #000000";
		computercardHeader.style.background = "url('img/" + currentComputerCard[0] + ".jpg') no-repeat center center";
		computercardHeader.style.backgroundSize = "auto 105%";


    // Fill in computer card by looping through card-array
    var computercardCategories = document
      .getElementById("computercard_categories");
    computercardCategories.innerHTML = "";
    for (i = 0; i < chosenCategories.length; i+=1) {

      var currentCategory = chosenCategories[i];

      // make new row
      var newRow = document.createElement("div");
      newRow.id = "computer_category_row" + currentCategory;
      newRow.classList.add("list-group-item", "d-flex",
                           "w-100", "justify-content-between");
      document.getElementById("computercard_categories").appendChild(newRow);

      // category
      var newCat = document.createElement("h6");
      var newCatContent = document.createTextNode(data_header[currentCategory]);
      newCat.appendChild(newCatContent);
      document.getElementById("computer_category_row" + currentCategory)
        .appendChild(newCat);

      // show value
      var newVal = document.createElement("span");
      var currentValue = formatNumbers(currentComputerCard[currentCategory]);
      var newValContent = document
        .createTextNode(currentValue + data_suffix[currentCategory]);
      newVal.appendChild(newValContent);
      newVal.id = "computercardCategory" + currentCategory;
      newVal.classList.add("category_nolink");
      document.getElementById("computer_category_row" + currentCategory)
        .appendChild(newVal);
    }
  }, 500);
}


// functions needed when page loads
$(document).ready(function() {

  startGameButton = document.getElementById("startGame");
  startGameButton.addEventListener("click", initGame);

  startTurnButton = document.getElementById("startTurn");
  startTurnButton.addEventListener("click", initTurn);

  newGameButton = document.getElementById("newGame");
  newGameButton.addEventListener("click", initNewGame);

  showSummaryButton = document.getElementById("showSummary");
  showSummaryButton.addEventListener("click", initSummary);

  waitingButton = document.getElementById("waiting");

  infoLine = document.getElementById("info_line");
  summaryList = document.getElementById("summary_list");
  gameProgressBar = document.getElementById("gameProgress");

  computerCardDiv = document.getElementById("computercard");


  // Players turn: player chooses category
  $(document).on("click", ".category_link", function(event) {

    if (stateOfGame == 5) {

      var computerCardDiv = document.getElementById("computercard");
      var firstComputerCard = currentComputerCard;
      var firstPlayerCard = currentPlayerCard;

      // turn over computer card
      computerCardDiv.classList.toggle("flip");

      // log the chosen category
      var categoryID = parseInt(this.id.slice(-1));
      if (categoryID == 0) {
        categoryID = 10;
      }
      var chosenPlayerCategory = document
        .getElementById("playercardCategory" + categoryID);
      var chosenComputerCategory = document
        .getElementById("computercardCategory" + categoryID);

      // Prepare summary entry

      var newSummaryLine = document.createElement("div");
      newSummaryLine.classList.add("d-flex", "w-100", "border-top", "py-1");


      var newSummaryPlayer = document.createElement("div");
      newSummaryPlayer.classList.add("text-right", "summary_left")
      newSummaryPlayer.innerHTML = currentPlayerCard[0] + "<br>" +
        formatNumbers(currentPlayerCard[categoryID]) + data_suffix[categoryID];

      var newSummaryCat = document.createElement("div");
      newSummaryCat.classList
        .add("text-center", "d-inline-block", "px-1", "text-secondary", "summary_center")
      newSummaryCat.innerHTML = "<i>" + summary_header[categoryID] + "</i>";

      var newSummaryComputer = document.createElement("div");
      newSummaryComputer.classList.add("text-left", "summary_right")
      newSummaryComputer.innerHTML = currentComputerCard[0] + "<br>" +
        formatNumbers(currentComputerCard[categoryID]) +data_suffix[categoryID];

      if (data_comparison[categoryID] == "larger") {
        if (firstPlayerCard[categoryID] > firstComputerCard[categoryID]) {
          newSummaryPlayer.classList.add("winner");
        } else if (firstPlayerCard[categoryID] < firstComputerCard[categoryID]){
          newSummaryComputer.classList.add("winner");
        }
      } else {
        if (firstPlayerCard[categoryID] < firstComputerCard[categoryID]) {
          newSummaryPlayer.classList.add("winner");
        } else if (firstPlayerCard[categoryID] > firstComputerCard[categoryID]){
          newSummaryComputer.classList.add("winner");
        }
      }

      newSummaryLine.appendChild(newSummaryPlayer);
      newSummaryLine.appendChild(newSummaryCat);
      newSummaryLine.appendChild(newSummaryComputer);

      summaryList.appendChild(newSummaryLine);

      // Prepare progress-bar

      var progressBarWin = document.createElement("div");
      progressBarWin.classList.add("progress-bar", "bg-success");
      progressBarWin.style = progressBarPercentage;
      progressBarWin.role = "progressbar";

      var progressBarLose = document.createElement("div");
      progressBarLose.classList.add("progress-bar", "bg-danger");
      progressBarLose.style = progressBarPercentage;
      progressBarLose.role = "progressbar";

      var progressBarDraw = document.createElement("div");
      progressBarDraw.classList.add("progress-bar", "bg-warning");
      progressBarDraw.style = progressBarPercentage;
      progressBarDraw.role = "progressbar";

      // compare values, change message accordingly, update score

      if (data_comparison[categoryID] == "larger") {
        if (firstPlayerCard[categoryID] > firstComputerCard[categoryID]) {
          chosenPlayerCategory.classList.add("text-success");
          chosenComputerCategory.classList.add("text-danger");
          infoLine.classList.remove("text-light");
          infoLine.classList.add("text-success");
          infoLine.innerHTML = "<h4 class='mb-1'>" + turnWonMsg + "</h4>";
          gameProgressBar.appendChild(progressBarWin);
          playerPoints += 1;
        } else if (firstPlayerCard[categoryID] < firstComputerCard[categoryID]){
          chosenPlayerCategory.classList.add("text-danger");
          chosenComputerCategory.classList.add("text-success");
          infoLine.classList.remove("text-light");
          infoLine.classList.add("text-danger");
          infoLine.innerHTML = "<h4 class='mb-1'>" + turnLostMsg + "</h4>";
          gameProgressBar.appendChild(progressBarLose);
          computerPoints += 1;
        } else {
          chosenPlayerCategory.classList.add("text-warning");
          chosenComputerCategory.classList.add("text-warning");
          infoLine.classList.remove("text-light");
          infoLine.classList.add("text-warning");
          infoLine.innerHTML = "<h4 class='mb-1'>" + turnDrawMsg + "</h4>";
          gameProgressBar.appendChild(progressBarDraw);
        }
      } else {
        if (firstPlayerCard[categoryID] < firstComputerCard[categoryID]) {
          chosenPlayerCategory.classList.add("text-success");
          chosenComputerCategory.classList.add("text-danger");
          infoLine.classList.remove("text-light");
          infoLine.classList.add("text-success");
          infoLine.innerHTML = "<h4 class='mb-1'>" + turnWonMsg + "</h4>";
          playerPoints += 1;
          gameProgressBar.appendChild(progressBarWin);
        } else if (firstPlayerCard[categoryID] > firstComputerCard[categoryID]){
          chosenPlayerCategory.classList.add("text-danger");
          chosenComputerCategory.classList.add("text-success");
          infoLine.classList.remove("text-light");
          infoLine.classList.add("text-danger");
          gameProgressBar.appendChild(progressBarLose);
          infoLine.innerHTML = "<h4 class='mb-1'>" + turnLostMsg + "</h4>";
          computerPoints += 1;
        } else {
          chosenPlayerCategory.classList.add("text-warning");
          chosenComputerCategory.classList.add("text-warning");
          infoLine.classList.remove("text-light");
          infoLine.classList.add("text-warning");
          infoLine.innerHTML = "<h4 class='mb-1'>" + turnDrawMsg + "</h4>";
          gameProgressBar.appendChild(progressBarDraw);
        }
      }

      updateScore();


      //remove current card from decks

      playerCards.shift();
      computerCards.shift();
      currentRound += 1;

      // Proceed: Next card, if cards left or summary, if no cards left

      if (playerCards.length > 0) {
        updateButtons(4);
      } else {
        updateButtons(6);
        infoLine.classList.remove("text-success");
        infoLine.classList.remove("text-warning");
        infoLine.classList.remove("text-danger");
        infoLine.classList.add("text-light");
        infoLine.innerHTML = "<h4 class='mb-1'>" + gameOverMsg + "</h4>";
      }

    }

  } );

  // Show gameMode-Chooser on load - GAME IS STARTED HERE
  updateButtons(1);

});


// initiate new game after a game is finished
function initNewGame() {
  // updateButtons(1);
  window.location.reload()
}


function initGame() {
  //Function to initiate the actual game

  // Shuffle and deal cards
  shuffleCards();
  buildDecks();

  // Show cards and beginn game
  updateButtons(3);

  // Reset score
  playerPoints = 0;
  computerPoints = 0;
  updateScore();

  // Reset progress bar
  while (gameProgressBar.hasChildNodes()) {
    gameProgressBar.removeChild(gameProgressBar.lastChild);
  }

  // Start turn
  initTurn()
}

function initSummary() {
  //Function to display a summary of each turn after the game

  // Change buttons when summary is shown
  updateButtons(7)

  var summaryHeadline = document.getElementById("summaryHeadline");

  if (playerPoints > computerPoints) {
    summaryHeadline.innerHTML = "<h3 class='text-success'>" + gameWonMsg +
      playerPoints + ":" + computerPoints + "</h3>";
  }
  if (playerPoints < computerPoints) {
    summaryHeadline.innerHTML = "<h3 class='text-danger'>" + gameLostMsg +
      playerPoints + ":" + computerPoints + "</h3>";
  }
  if (playerPoints == computerPoints) {
    summaryHeadline.innerHTML = "<h3 class='text-warning'>" + gameDrawMsg +
      playerPoints + ":" + computerPoints + "</h3>";
  }
}

function initTurn() {
  //Function to initiate the next turn by showing the topmost player card

  updateButtons(5);

  // choose first card from each deck
  currentPlayerCard = playerCards[0];
  currentComputerCard = computerCards[0];

  // Change heading of player card
  var playercardHeader = document.getElementById("playercard_header");
	playercardHeader.innerHTML = "<h3 class='m-3 card-title text-white'>" +
                                 currentPlayerCard[0] + "</h3>";
  playercardHeader.style.height = "200px";
	playercardHeader.style.borderTopLeftRadius = "inherit";
	playercardHeader.style.borderTopRightRadius = "inherit";
	playercardHeader.style.textShadow = "0px 0px 4px #000000";
	playercardHeader.style.background = "url('img/" + currentPlayerCard[0] + ".jpg') no-repeat center center";
	playercardHeader.style.backgroundSize = "auto 105%";


  // Fill in player card by looping through card-array
  var playercardCategories = document.getElementById("playercard_categories");
  playercardCategories.innerHTML = "";
  for (i = 0; i < chosenCategories.length; i+=1) {

    var currentCategory = chosenCategories[i];

    // make new row
    var newRow = document.createElement("div");
    newRow.id = "player_category_row" + currentCategory;
    newRow.classList
      .add("list-group-item");
    document.getElementById("playercard_categories").appendChild(newRow);

    // category
    var newCat = document.createElement("h6");
    var newCatContent = document.createTextNode(data_header[currentCategory]);
    newCat.appendChild(newCatContent);

    // value


    var newVal = document.createElement("h6");
    var currentValue = formatNumbers(currentPlayerCard[currentCategory]);
    var newValContent = document
      .createTextNode(currentValue + data_suffix[currentCategory]);
    newVal.appendChild(newValContent);

    // link whole row
    var newRowLink = document.createElement("a");
    newRowLink.id = "playercardCategory" + currentCategory;
    newRowLink.href = "#";
    newRowLink.classList
      .add("category_link", "d-flex", "w-100", "justify-content-between");
    newRowLink.appendChild(newCat);
    newRowLink.appendChild(newVal);
    document.getElementById("player_category_row" + currentCategory)
      .appendChild(newRowLink);

  }

  buildComputerCard();

}
